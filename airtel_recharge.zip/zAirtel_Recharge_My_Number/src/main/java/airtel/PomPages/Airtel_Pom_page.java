package airtel.PomPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Airtel_Pom_page {
	public Airtel_Pom_page(WebDriver driver) {
		PageFactory.initElements(driver,this);
	}
	@FindAll({@FindBy(xpath="//label[text()='Prepaid']"),@FindBy(xpath="//label[text()='Prepaid'][@class='wt-typography']")})
	private WebElement prepaid;
	@FindAll({@FindBy(xpath="(//label[text()='Recharge']/..)[1]"),@FindBy(xpath="(//*/a[contains(@href,'https://www.airtel.in/prepaid-r')])[1]")})
	private WebElement recharge;
	@FindBy(xpath = "//h1[text()='Prepaid mobile recharge']")
	private WebElement validate;
	@FindBy(xpath="//input[@type='tel'][@placeholder=\"Enter your 10-digit mobile number\"]")
	private WebElement mobile_number;
	@FindBy(xpath ="//button[@class='wt-btn no-text-transform']")
	private WebElement change_no;
	@FindBy(xpath="//*[text()='Recharge Packs']")
	private WebElement validate2;
	@FindBy(xpath="(//*[text()='VIEW DETAILS'])[1]")
	private WebElement ViewDetails;
	@FindBy(xpath="//*[text()='RECHARGE NOW']")
	private WebElement Recharge1;
	@FindBy(xpath="//*[text()='Payment Summary']")
	private WebElement plan_details_block;
	@FindBy(xpath="//*[text()='Payment options']")
	private WebElement Recharge_block;
	@FindBy(xpath="//h3")
	private WebElement inside_Recharge_block;
	@FindBy(xpath="(//div[@id='accordion-header-3']/..)")
	private WebElement attempt_to_pay;
	@FindBy(xpath="//div//li//h4[text()='Airtel Money']")
	private WebElement Airtel_Money;
	@FindBy(xpath="//button[text()='Pay Now']")
	private WebElement Airtel_pay_now;
	@FindBy(xpath="//input[@type='tel'][@id='mobile-number']")
	private WebElement Airtel_recharge_page;
	@FindBy(xpath="(//div[text()='Get OTP'])[1]")
	private WebElement Airtel_recharge_otp;
	@FindBy(xpath="(//span[contains(text(),'We value your')])[1]")
	private WebElement Airtel_recharge_feedback;
	@FindBy(xpath="//div/li[contains(text(),'My reason is not listed.')]")
	private WebElement Airtel_recharge_others;
	@FindBy(xpath="//div/textarea[@name='comment']")
	private WebElement text_send;
	@FindBy(xpath="//button[@type='button'][@class='submit size-14']")
	private WebElement submitting;
	@FindBy(xpath="//p[text()='payment pending']")
	private WebElement payment_pending;
	@FindBy(xpath="(//span[text()='Okay']/..)")
	private WebElement click_okay;
	public WebElement getPrepaid() {
		return prepaid;
	}
	public void setPrepaid(WebElement prepaid) {
		this.prepaid = prepaid;
	}
	public WebElement getRecharge() {
		return recharge;
	}
	public void setRecharge(WebElement recharge) {
		this.recharge = recharge;
	}
	public WebElement getValidate() {
		return validate;
	}
	public void setValidate(WebElement validate) {
		this.validate = validate;
	}
	public WebElement getMobile_number() {
		return mobile_number;
	}
	public void setMobile_number(WebElement mobile_number) {
		this.mobile_number = mobile_number;
	}
	public WebElement getChange_no() {
		return change_no;
	}
	public void setChange_no(WebElement change_no) {
		this.change_no = change_no;
	}
	public WebElement getValidate2() {
		return validate2;
	}
	public void setValidate2(WebElement validate2) {
		this.validate2 = validate2;
	}
	public WebElement getViewDetails() {
		return ViewDetails;
	}
	public void setViewDetails(WebElement viewDetails) {
		ViewDetails = viewDetails;
	}
	public WebElement getRecharge1() {
		return Recharge1;
	}
	public void setRecharge1(WebElement recharge1) {
		Recharge1 = recharge1;
	}
	public WebElement getPlan_details_block() {
		return plan_details_block;
	}
	public void setPlan_details_block(WebElement plan_details_block) {
		this.plan_details_block = plan_details_block;
	}
	public WebElement getRecharge_block() {
		return Recharge_block;
	}
	public void setRecharge_block(WebElement recharge_block) {
		Recharge_block = recharge_block;
	}
	public WebElement getInside_Recharge_block() {
		return inside_Recharge_block;
	}
	public void setInside_Recharge_block(WebElement inside_Recharge_block) {
		this.inside_Recharge_block = inside_Recharge_block;
	}
	public WebElement getAttempt_to_pay() {
		return attempt_to_pay;
	}
	public void setAttempt_to_pay(WebElement attempt_to_pay) {
		this.attempt_to_pay = attempt_to_pay;
	}
	public WebElement getAirtel_Money() {
		return Airtel_Money;
	}
	public void setAirtel_Money(WebElement airtel_Money) {
		Airtel_Money = airtel_Money;
	}
	public WebElement getAirtel_pay_now() {
		return Airtel_pay_now;
	}
	public void setAirtel_pay_now(WebElement airtel_pay_now) {
		Airtel_pay_now = airtel_pay_now;
	}
	public WebElement getAirtel_recharge_page() {
		return Airtel_recharge_page;
	}
	public void setAirtel_recharge_page(WebElement airtel_recharge_page) {
		Airtel_recharge_page = airtel_recharge_page;
	}
	public WebElement getAirtel_recharge_otp() {
		return Airtel_recharge_otp;
	}
	public void setAirtel_recharge_otp(WebElement airtel_recharge_otp) {
		Airtel_recharge_otp = airtel_recharge_otp;
	}
	public WebElement getAirtel_recharge_feedback() {
		return Airtel_recharge_feedback;
	}
	public void setAirtel_recharge_feedback(WebElement airtel_recharge_feedback) {
		Airtel_recharge_feedback = airtel_recharge_feedback;
	}
	public WebElement getAirtel_recharge_others() {
		return Airtel_recharge_others;
	}
	public void setAirtel_recharge_others(WebElement airtel_recharge_others) {
		Airtel_recharge_others = airtel_recharge_others;
	}
	public WebElement getText_send() {
		return text_send;
	}
	public void setText_send(WebElement text_send) {
		this.text_send = text_send;
	}
	public WebElement getSubmitting() {
		return submitting;
	}
	public void setSubmitting(WebElement submitting) {
		this.submitting = submitting;
	}
	public WebElement getPayment_pending() {
		return payment_pending;
	}
	public void setPayment_pending(WebElement payment_pending) {
		this.payment_pending = payment_pending;
	}
	public WebElement getClick_okay() {
		return click_okay;
	}
	public void setClick_okay(WebElement click_okay) {
		this.click_okay = click_okay;
	}
}
