package airtel.GenericUtils;

public class Airtel_IframeConstant {
	static String Propertypath = ".\\src\\main\\resources\\Airtel.properties";
}
