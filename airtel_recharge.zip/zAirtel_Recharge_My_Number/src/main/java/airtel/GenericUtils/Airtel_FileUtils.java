package airtel.GenericUtils;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class Airtel_FileUtils {
	public String read_Data(String key) throws IOException {
		FileInputStream fis = new FileInputStream(Airtel_IframeConstant.Propertypath);
		Properties pr = new Properties();
		pr.load(fis);
		String value = pr.getProperty(key);
		return value;
	}
}
