package airtel.TestCase;

import java.io.IOException;
import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import airtel.GenericUtils.Airtel_FileUtils;
import airtel.PomPages.Airtel_Pom_page;

public class Airtel_Test_case_runner {
	private WebDriver driver;
	private WebDriverWait wait;
	private Airtel_FileUtils Afs;
	private Airtel_Pom_page apm;
	private Actions act;

	@BeforeClass
	public void setup() {
		driver = new ChromeDriver();
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		driver.manage().window().maximize();
		act = new Actions(driver);
		Afs = new Airtel_FileUtils();
		apm = new Airtel_Pom_page(driver);
	}

	@Test
	public void Recharge_my_no_Airtel() throws IOException {
		String URL = Afs.read_Data("URL");
		String USRP = Afs.read_Data("Phone_number");
		driver.navigate().to(URL);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
		try {
			act.moveToElement(apm.getPrepaid()).build().perform();
			wait.until(ExpectedConditions.elementToBeClickable(apm.getRecharge())).click();
			if (apm.getValidate().isDisplayed()) {
				System.out.println(apm.getValidate().getText());
			}
			wait.until(ExpectedConditions.elementToBeClickable(apm.getMobile_number())).sendKeys(USRP);
			wait.until(ExpectedConditions.elementToBeClickable(apm.getChange_no())).click();
			wait.until(ExpectedConditions.elementToBeClickable(apm.getMobile_number())).sendKeys(USRP);
			if (apm.getValidate2().isDisplayed()) {
				System.out.println(apm.getValidate2().getText());
			}
			wait.until(ExpectedConditions.elementToBeClickable(apm.getViewDetails())).click();
			wait.until(ExpectedConditions.elementToBeClickable(apm.getRecharge1())).click();
			wait.until(ExpectedConditions.elementToBeClickable(apm.getAttempt_to_pay())).click();
			wait.until(ExpectedConditions.elementToBeClickable(apm.getAirtel_Money())).click();
			wait.until(ExpectedConditions.elementToBeClickable(apm.getAirtel_pay_now())).click();
           
			wait.until(ExpectedConditions.elementToBeClickable(apm.getAirtel_recharge_page())).sendKeys(USRP);
			if (apm.getAirtel_recharge_otp().isDisplayed()) {
				System.out.println("i'm here at " + apm.getAirtel_recharge_otp().getText());
			}
			driver.navigate().back();
			try {
			if (apm.getAirtel_recharge_feedback().isDisplayed()) {
				wait.until(ExpectedConditions.elementToBeClickable(apm.getAirtel_recharge_feedback())).click();
				wait.until(ExpectedConditions.elementToBeClickable(apm.getAirtel_recharge_others())).click();
				wait.until(ExpectedConditions.elementToBeClickable(apm.getText_send()))
						.sendKeys("i wanted free recharge my name is Shakalaka boom");
				wait.until(ExpectedConditions.elementToBeClickable(apm.getSubmitting())).click();
				if (apm.getPayment_pending().isDisplayed()) {
					System.out.println(apm.getPayment_pending().getText());
				}
				wait.until(ExpectedConditions.elementToBeClickable(apm.getClick_okay())).click();
			}
			}catch(Exception e) {
				e.printStackTrace();
			}
			driver.navigate().refresh();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			driver.quit();
		}
	}

}