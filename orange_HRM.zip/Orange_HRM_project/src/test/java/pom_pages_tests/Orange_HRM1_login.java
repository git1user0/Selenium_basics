package pom_pages_tests;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

import com.Generic_utils.FileUtils;

import pom_pages_.POM_loginpage;

public class Orange_HRM1_login {
	@Test
	public void login_test() throws InterruptedException, IOException {
		WebDriver driver = new FirefoxDriver();
		driver.manage().window().maximize();
		FileUtils fs = new FileUtils();
		String URL = fs.read_data("url");
		String USR = fs.read_data("Loginpage_Username");
		String PAS = fs.read_data("Loginpage_Password");
		driver.get(URL);
		POM_loginpage pl = new POM_loginpage(driver);
		Thread.sleep(2000);
		pl.login_to_page(USR, PAS);
		Thread.sleep(5000);
		driver.navigate().refresh();
		Thread.sleep(3000);
		pl.login_to_page(USR, PAS);
		Thread.sleep(2000);
		pl.getLogin_btn().click();
		Thread.sleep(2000);
		System.out.println(pl.getVerification().getText());
		Thread.sleep(2000);
		pl.getLogout_1().click();
		Thread.sleep(2000);
		pl.getLogout_2().click();
		Thread.sleep(2000);
		driver.quit();
	}
}
