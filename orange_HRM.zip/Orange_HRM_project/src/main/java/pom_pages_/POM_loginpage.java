package pom_pages_;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class POM_loginpage {
	public POM_loginpage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		    
	}
 // user name locators
	@FindAll({ @FindBy(xpath = "//input[@name='username']"), @FindBy(xpath = "//input[@placeholder='Username']") })
	private WebElement User_na;

	public WebElement getUser_na() {
		return User_na;
	}

	public void setUser_na(WebElement user_na) {
		User_na = user_na;
	}
	// ------------------------------------------
	 // Pass word locators
		@FindAll({ @FindBy(xpath = "//input[@name='password']"), @FindBy(xpath = "//input[@placeholder='Password']") })
		private WebElement Pass_na;
		
		public WebElement getPass_na() {
			return Pass_na;
		}

		public void setPass_na(WebElement pass_na) {
			Pass_na = pass_na;
		}
		
		// _________________Login_________________________
		
		@FindAll({ @FindBy(xpath = "//button[contains(@class,'login-button')]"), @FindBy(xpath = "//button[@type='submit']") })
		private WebElement Login_btn;

		public WebElement getLogin_btn() {
			return Login_btn;
		}

		public void setLogin_btn(WebElement login_btn) {
			Login_btn = login_btn;
		}
		// _____________verification________________________________
		@FindBy(xpath = "//p[contains(@class,'down-name')]")
		private WebElement Verification;

		public WebElement getVerification() {
			return Verification;
		}

		public void setVerification(WebElement verification) {
			Verification = verification;
		}
		
		// -------------------------------------------------------
		@FindBy(xpath = "//i[contains(@class,'oxd-userdropdown-')]")
		private WebElement logout_1;
		
		public WebElement getLogout_1() {
			return logout_1;
		}

		public void setLogout_1(WebElement logout_1) {
			this.logout_1 = logout_1;
		}
        
		@FindAll({ @FindBy(xpath = "//a[contains(@href,'logout')]"), @FindBy(xpath = "//a[contains(text(),'Logout')]") })
		public WebElement Logout_2;
		
		public WebElement getLogout_2() {
			return Logout_2;
		}

		public void setLogout_2(WebElement logout_2) {
			Logout_2 = logout_2;
		}

		//______________________business logic________________________
		// Business logic implementation in page only
		public void login_to_page(String username,String password) {
			User_na.sendKeys(username);
			Pass_na.sendKeys(password);
			//Login_btn.click();
			
		}
}
