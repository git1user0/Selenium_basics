package com.Generic_utils;

public interface IframeConstant {
	String PropertyFilePath=".\\src\\main\\resources\\Orange_HRM.properties";
}
