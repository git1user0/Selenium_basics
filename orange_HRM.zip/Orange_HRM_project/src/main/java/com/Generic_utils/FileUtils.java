package com.Generic_utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class FileUtils {
	public String read_data(String key) throws IOException{
		FileInputStream fis = new FileInputStream(IframeConstant.PropertyFilePath);
		//FileInputStream fis = FileInputStream(IframeConstant.PropertyFilePath);
		Properties pro = new Properties();
		pro.load(fis);
		String value = pro.getProperty(key);
		
		return value;
	}

}
